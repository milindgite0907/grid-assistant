import type { DataGridBodyState } from './DataGridBody.types';
/**
 * Apply styling to the DataGridBody slots based on the state
 */
export declare const useDataGridBodyStyles_unstable: (state: DataGridBodyState) => DataGridBodyState;
