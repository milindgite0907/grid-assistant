import type { JSXElement } from '@fluentui/react-components';
import type { DataGridBodyState } from './DataGridBody.types';
/**
 * Render the final JSX of DataGridVirtualizedBody
 */
export declare const renderDataGridBody_unstable: (state: DataGridBodyState) => JSXElement;
