import type { ForwardRefComponent } from '@fluentui/react-components';
import type { JSXElement } from '@fluentui/react-components';
import type { DataGridBodyProps } from './DataGridBody.types';
/**
 * DataGridBody component
 */
export declare const DataGridBody: ForwardRefComponent<DataGridBodyProps> & (<TItem>(props: DataGridBodyProps<TItem>) => JSXElement);
