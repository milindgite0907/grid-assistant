import * as React from 'react';
import { DataGridHeaderProps, DataGridHeaderState } from '@fluentui/react-components';
/**
 * Create the state required to render DataGridHeader.
 *
 * The returned state can be modified with hooks such as useDataGridHeaderStyles_unstable,
 * before being passed to renderDataGridHeader_unstable.
 *
 * @param props - props from this instance of DataGridHeader
 * @param ref - reference to root HTMLElement of DataGridHeader
 */
export declare const useDataGridHeader_unstable: (props: DataGridHeaderProps, ref: React.Ref<HTMLElement>) => DataGridHeaderState;
