import { type DataGridHeaderProps, type ForwardRefComponent } from '@fluentui/react-components';
import type { JSXElement } from '@fluentui/react-components';
/**
 * DataGridHeader component
 */
export declare const DataGridHeader: ForwardRefComponent<DataGridHeaderProps> & ((props: DataGridHeaderProps) => JSXElement);
