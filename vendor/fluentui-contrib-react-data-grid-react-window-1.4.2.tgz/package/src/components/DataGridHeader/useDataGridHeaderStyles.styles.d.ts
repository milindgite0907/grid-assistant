import { DataGridHeaderState } from '@fluentui/react-components';
/**
 * Apply styling to the DataGridHeader slots based on the state
 */
export declare const useDataGridHeaderStyles_unstable: (state: DataGridHeaderState) => DataGridHeaderState;
