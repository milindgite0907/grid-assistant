import { DataGridContextValues } from '@fluentui/react-components';
import type { JSXElement } from '@fluentui/react-components';
import { DataGridState } from './DataGrid.types';
/**
 * Render the final JSX of DataGrid
 */
export declare const renderDataGrid_unstable: (state: DataGridState, contextValues: DataGridContextValues) => JSXElement;
