import { DataGridProps } from '@fluentui/react-components';
import type { ForwardRefComponent } from '@fluentui/react-components';
export declare const DataGrid: ForwardRefComponent<DataGridProps>;
