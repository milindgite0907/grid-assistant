import * as React from 'react';
import { DataGridProps } from '@fluentui/react-components';
import { DataGridState } from './DataGrid.types';
/**
 * Create the state required to render DataGrid.
 *
 * The returned state can be modified with hooks such as useDataGridStyles_unstable,
 * before being passed to renderDataGrid_unstable.
 *
 * @param props - props from this instance of DataGrid
 * @param ref - reference to root HTMLElement of DataGrid
 */
export declare const useDataGrid_unstable: (props: DataGridProps, ref: React.Ref<HTMLElement>) => DataGridState;
