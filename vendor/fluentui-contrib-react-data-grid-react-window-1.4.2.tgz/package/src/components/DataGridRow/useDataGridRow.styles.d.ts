import { DataGridRowState } from '@fluentui/react-components';
/**
 * Apply styling to the DataGridRow slots based on the state
 */
export declare const useDataGridRowStyles_unstable: (state: DataGridRowState) => DataGridRowState;
