import { DataGridRowProps } from '@fluentui/react-components';
import type { ForwardRefComponent } from '@fluentui/react-components';
import type { JSXElement } from '@fluentui/react-components';
/**
 * DataGridRow component
 */
export declare const DataGridRow: ForwardRefComponent<DataGridRowProps> & (<TItem>(props: DataGridRowProps<TItem>) => JSXElement);
