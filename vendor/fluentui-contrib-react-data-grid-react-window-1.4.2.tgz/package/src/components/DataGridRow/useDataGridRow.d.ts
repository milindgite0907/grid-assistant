import * as React from 'react';
import type { DataGridRowProps, DataGridRowState } from '@fluentui/react-components';
/**
 * Create the state required to render DataGridRow.
 *
 * The returned state can be modified with hooks such as useDataGridRowStyles_unstable,
 * before being passed to renderDataGridRow_unstable.
 *
 * @param props - props from this instance of DataGridRow
 * @param ref - reference to root HTMLElement of DataGridRow
 */
export declare const useDataGridRow_unstable: (props: DataGridRowProps, ref: React.Ref<HTMLElement>) => DataGridRowState;
