import * as React from 'react';
export declare const bodyRefContextDefaultValue: React.MutableRefObject<HTMLElement | null>;
export declare const useBodyRefContext: () => React.MutableRefObject<HTMLElement | null>;
export declare const BodyRefContextProvider: React.Provider<React.MutableRefObject<HTMLElement | null>>;
