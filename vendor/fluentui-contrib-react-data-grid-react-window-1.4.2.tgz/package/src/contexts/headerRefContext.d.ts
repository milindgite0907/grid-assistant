import * as React from 'react';
export declare const headerRefContextDefaultValue: React.MutableRefObject<HTMLElement | null>;
export declare const useHeaderRefContext: () => React.MutableRefObject<HTMLElement | null>;
export declare const HeaderRefContextProvider: React.Provider<React.MutableRefObject<HTMLElement | null>>;
