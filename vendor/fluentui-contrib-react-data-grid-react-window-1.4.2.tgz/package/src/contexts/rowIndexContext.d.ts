import * as React from 'react';
export declare const tableRowIndexContextDefaultValue: undefined;
export declare const useTableRowIndexContext: () => number | undefined;
export declare const TableRowIndexContextProvider: React.Provider<number | undefined>;
