"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "renderDataGridBody_unstable", {
    enumerable: true,
    get: function() {
        return renderDataGridBody_unstable;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _reactcomponents = require("@fluentui/react-components");
const _reactwindow = require("react-window");
const renderDataGridBody_unstable = (state)=>{
    const { slots, slotProps } = (0, _reactcomponents.getSlots)(state);
    const { dir } = (0, _reactcomponents.useFluent)();
    return /*#__PURE__*/ _react.createElement(slots.root, slotProps.root, /*#__PURE__*/ _react.createElement(_reactwindow.FixedSizeList, {
        itemSize: state.itemSize,
        width: state.width,
        itemData: state.rows,
        height: state.height,
        itemCount: state.rows.length,
        direction: dir,
        outerRef: state.outerRef,
        ...state.listProps
    }, state.virtualizedRow));
};

//# sourceMappingURL=renderDataGridBody.js.map