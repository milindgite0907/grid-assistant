"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useDataGridBody_unstable", {
    enumerable: true,
    get: function() {
        return useDataGridBody_unstable;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _reactcomponents = require("@fluentui/react-components");
const _rowIndexContext = require("../../contexts/rowIndexContext");
const _bodyRefContext = require("../../contexts/bodyRefContext");
const _headerRefContext = require("../../contexts/headerRefContext");
const useDataGridBody_unstable = (props, ref)=>{
    const { height, itemSize, width = '100%', ariaRowIndexStart = 2, children, listProps } = props;
    const bodyRef = (0, _bodyRefContext.useBodyRefContext)();
    const headerRef = (0, _headerRefContext.useHeaderRefContext)();
    // cast the row render function to work with unknown args
    const renderRowWithUnknown = children;
    const baseState = (0, _reactcomponents.useDataGridBody_unstable)({
        ...props,
        children: renderRowWithUnknown
    }, ref);
    const virtualizedRow = _react.useCallback(({ data, index, style, isScrolling })=>{
        const row = data[index];
        return /*#__PURE__*/ _react.createElement(_rowIndexContext.TableRowIndexContextProvider, {
            value: ariaRowIndexStart + index
        }, /*#__PURE__*/ _react.createElement(_reactcomponents.TableRowIdContextProvider, {
            value: row.rowId
        }, children(row, style, index, isScrolling)));
    }, [
        ariaRowIndexStart,
        children
    ]);
    const onScroll = _react.useCallback(()=>{
        if (bodyRef.current && headerRef.current) {
            headerRef.current.scroll({
                left: bodyRef.current.scrollLeft,
                behavior: 'instant'
            });
        }
    }, []);
    // Use a onScroll callback on the outerElement since react-window's onScroll will only work for horizontal scrolls
    const setupOuterRef = _react.useCallback((outerElement)=>{
        var _bodyRef_current;
        (_bodyRef_current = bodyRef.current) == null ? void 0 : _bodyRef_current.removeEventListener('scroll', onScroll);
        bodyRef.current = outerElement;
        if (outerElement) {
            outerElement.addEventListener('scroll', onScroll);
        }
    }, []);
    return {
        ...baseState,
        itemSize,
        height,
        virtualizedRow,
        width,
        ariaRowIndexStart,
        listProps,
        outerRef: setupOuterRef
    };
};

//# sourceMappingURL=useDataGridBody.js.map