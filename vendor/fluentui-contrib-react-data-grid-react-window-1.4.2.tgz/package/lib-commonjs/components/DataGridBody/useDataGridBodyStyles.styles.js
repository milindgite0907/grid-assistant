"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useDataGridBodyStyles_unstable", {
    enumerable: true,
    get: function() {
        return useDataGridBodyStyles_unstable;
    }
});
const _reactcomponents = require("@fluentui/react-components");
const useDataGridBodyStyles_unstable = (state)=>{
    (0, _reactcomponents.useDataGridBodyStyles_unstable)({
        ...state,
        renderRow: ()=>null
    });
    return state;
};

//# sourceMappingURL=useDataGridBodyStyles.styles.js.map