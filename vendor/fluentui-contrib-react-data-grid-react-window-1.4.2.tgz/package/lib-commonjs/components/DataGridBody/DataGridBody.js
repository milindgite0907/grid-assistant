"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DataGridBody", {
    enumerable: true,
    get: function() {
        return DataGridBody;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _useDataGridBodyStylesstyles = require("./useDataGridBodyStyles.styles");
const _useDataGridBody = require("./useDataGridBody");
const _renderDataGridBody = require("./renderDataGridBody");
const DataGridBody = /*#__PURE__*/ _react.forwardRef((props, ref)=>{
    const state = (0, _useDataGridBody.useDataGridBody_unstable)(props, ref);
    (0, _useDataGridBodyStylesstyles.useDataGridBodyStyles_unstable)(state);
    return (0, _renderDataGridBody.renderDataGridBody_unstable)(state);
});
DataGridBody.displayName = 'DataGridBody';

//# sourceMappingURL=DataGridBody.js.map