"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DataGrid", {
    enumerable: true,
    get: function() {
        return DataGrid;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _useDataGrid = require("./useDataGrid");
const _renderDataGrid = require("./renderDataGrid");
const _reactcomponents = require("@fluentui/react-components");
const DataGrid = /*#__PURE__*/ _react.forwardRef((props, ref)=>{
    const state = (0, _useDataGrid.useDataGrid_unstable)(props, ref);
    (0, _reactcomponents.useDataGridStyles_unstable)(state);
    return (0, _renderDataGrid.renderDataGrid_unstable)(state, (0, _reactcomponents.useDataGridContextValues_unstable)(state));
});
DataGrid.displayName = 'DataGrid';

//# sourceMappingURL=DataGrid.js.map