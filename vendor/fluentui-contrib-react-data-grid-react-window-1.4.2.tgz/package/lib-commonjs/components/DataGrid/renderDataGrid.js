"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "renderDataGrid_unstable", {
    enumerable: true,
    get: function() {
        return renderDataGrid_unstable;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _reactcomponents = require("@fluentui/react-components");
const _headerRefContext = require("../../contexts/headerRefContext");
const _bodyRefContext = require("../../contexts/bodyRefContext");
const renderDataGrid_unstable = (state, contextValues)=>{
    return /*#__PURE__*/ _react.createElement(_headerRefContext.HeaderRefContextProvider, {
        value: state.headerRef
    }, /*#__PURE__*/ _react.createElement(_bodyRefContext.BodyRefContextProvider, {
        value: state.bodyRef
    }, (0, _reactcomponents.renderDataGrid_unstable)(state, contextValues)));
};

//# sourceMappingURL=renderDataGrid.js.map