"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useDataGrid_unstable", {
    enumerable: true,
    get: function() {
        return useDataGrid_unstable;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _reactcomponents = require("@fluentui/react-components");
const TABLE_SELECTION_CELL_WIDTH = 44;
const useDataGrid_unstable = (props, ref)=>{
    var _props_resizableColumnsOptions;
    const { targetDocument } = (0, _reactcomponents.useFluent)();
    const scrollbarWidth = (0, _reactcomponents.useScrollbarWidth)({
        targetDocument
    });
    const headerRef = _react.useRef(null);
    const bodyRef = _react.useRef(null);
    let containerWidthOffset = props.containerWidthOffset;
    if (containerWidthOffset === undefined) {
        containerWidthOffset = props.selectionMode ? -TABLE_SELECTION_CELL_WIDTH : 0;
        containerWidthOffset -= scrollbarWidth || 0;
    }
    const baseState = (0, _reactcomponents.useDataGrid_unstable)({
        ...props,
        'aria-rowcount': props.items.length,
        containerWidthOffset
    }, ref);
    if (props.resizableColumns && ((_props_resizableColumnsOptions = props.resizableColumnsOptions) == null ? void 0 : _props_resizableColumnsOptions.autoFitColumns) === false && baseState.root.style) {
        baseState.root.style.minWidth = 'auto';
    }
    return {
        ...baseState,
        headerRef,
        bodyRef
    };
};

//# sourceMappingURL=useDataGrid.js.map