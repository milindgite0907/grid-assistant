"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DataGridRow", {
    enumerable: true,
    get: function() {
        return DataGridRow;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _reactcomponents = require("@fluentui/react-components");
const _useDataGridRow = require("./useDataGridRow");
const _useDataGridRowstyles = require("./useDataGridRow.styles");
const DataGridRow = /*#__PURE__*/ _react.forwardRef((props, ref)=>{
    const state = (0, _useDataGridRow.useDataGridRow_unstable)(props, ref);
    (0, _useDataGridRowstyles.useDataGridRowStyles_unstable)(state);
    return (0, _reactcomponents.renderDataGridRow_unstable)(state);
});
DataGridRow.displayName = 'DataGridRow';

//# sourceMappingURL=DataGridRow.js.map