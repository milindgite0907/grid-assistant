"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useDataGridRowStyles_unstable", {
    enumerable: true,
    get: function() {
        return useDataGridRowStyles_unstable;
    }
});
const _reactcomponents = require("@fluentui/react-components");
const useStyles = (0, _reactcomponents.makeStyles)({
    root: {
        minWidth: 'fit-content'
    }
});
const useDataGridRowStyles_unstable = (state)=>{
    const classes = useStyles();
    state.root.className = (0, _reactcomponents.mergeClasses)(classes.root, state.root.className);
    (0, _reactcomponents.useDataGridRowStyles_unstable)(state);
    return state;
};

//# sourceMappingURL=useDataGridRow.styles.js.map