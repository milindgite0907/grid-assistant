"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useDataGridRow_unstable", {
    enumerable: true,
    get: function() {
        return useDataGridRow_unstable;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _reactcomponents = require("@fluentui/react-components");
const _rowIndexContext = require("../../contexts/rowIndexContext");
const useDataGridRow_unstable = (props, ref)=>{
    const rowIndex = (0, _rowIndexContext.useTableRowIndexContext)();
    return (0, _reactcomponents.useDataGridRow_unstable)({
        ...props,
        'aria-rowindex': rowIndex
    }, ref);
};

//# sourceMappingURL=useDataGridRow.js.map