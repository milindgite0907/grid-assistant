"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useDataGridHeaderStyles_unstable", {
    enumerable: true,
    get: function() {
        return useDataGridHeaderStyles_unstable;
    }
});
const _reactcomponents = require("@fluentui/react-components");
const useStyles = (0, _reactcomponents.makeStyles)({
    root: {
        overflowX: 'auto',
        // Hide the scrollbar in the header, it is synced to the scrollbar of the body so shouldn't be shown
        scrollbarWidth: 'none',
        '::-webkit-scrollbar': {
            width: 0,
            height: 0
        }
    }
});
const useDataGridHeaderStyles_unstable = (state)=>{
    const classes = useStyles();
    state.root.className = (0, _reactcomponents.mergeClasses)(classes.root, state.root.className);
    (0, _reactcomponents.useDataGridHeaderStyles_unstable)(state);
    return state;
};

//# sourceMappingURL=useDataGridHeaderStyles.styles.js.map