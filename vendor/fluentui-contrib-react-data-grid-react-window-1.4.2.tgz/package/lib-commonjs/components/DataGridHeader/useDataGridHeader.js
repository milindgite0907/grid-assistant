"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useDataGridHeader_unstable", {
    enumerable: true,
    get: function() {
        return useDataGridHeader_unstable;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _reactcomponents = require("@fluentui/react-components");
const _bodyRefContext = require("../../contexts/bodyRefContext");
const _headerRefContext = require("../../contexts/headerRefContext");
const useDataGridHeader_unstable = (props, ref)=>{
    const bodyRef = (0, _bodyRefContext.useBodyRefContext)();
    const headerRef = (0, _headerRefContext.useHeaderRefContext)();
    const onScroll = _react.useCallback(()=>{
        if (bodyRef.current && headerRef.current) {
            bodyRef.current.scroll({
                left: headerRef.current.scrollLeft,
                behavior: 'instant'
            });
        }
    }, []);
    const setupScrollRef = _react.useCallback((element)=>{
        var _headerRef_current;
        (_headerRef_current = headerRef.current) == null ? void 0 : _headerRef_current.removeEventListener('scroll', onScroll);
        headerRef.current = element;
        if (element) {
            element.addEventListener('scroll', onScroll);
        }
    }, []);
    const baseState = (0, _reactcomponents.useDataGridHeader_unstable)(props, ref);
    baseState.root.ref = (0, _reactcomponents.useMergedRefs)(baseState.root.ref, setupScrollRef);
    return baseState;
};

//# sourceMappingURL=useDataGridHeader.js.map