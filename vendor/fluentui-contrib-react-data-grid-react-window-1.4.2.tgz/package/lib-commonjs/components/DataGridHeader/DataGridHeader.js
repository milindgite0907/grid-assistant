"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "DataGridHeader", {
    enumerable: true,
    get: function() {
        return DataGridHeader;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const _reactcomponents = require("@fluentui/react-components");
const _useDataGridHeader = require("./useDataGridHeader");
const _useDataGridHeaderStylesstyles = require("./useDataGridHeaderStyles.styles");
const DataGridHeader = /*#__PURE__*/ _react.forwardRef((props, ref)=>{
    const state = (0, _useDataGridHeader.useDataGridHeader_unstable)(props, ref);
    (0, _useDataGridHeaderStylesstyles.useDataGridHeaderStyles_unstable)(state);
    return (0, _reactcomponents.renderDataGridHeader_unstable)(state);
});
DataGridHeader.displayName = 'DataGridHeader';

//# sourceMappingURL=DataGridHeader.js.map