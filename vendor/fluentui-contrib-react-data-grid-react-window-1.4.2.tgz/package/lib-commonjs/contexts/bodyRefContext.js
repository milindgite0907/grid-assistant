"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get BodyRefContextProvider () {
        return BodyRefContextProvider;
    },
    get bodyRefContextDefaultValue () {
        return bodyRefContextDefaultValue;
    },
    get useBodyRefContext () {
        return useBodyRefContext;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const bodyRefContext = _react.createContext({
    current: null
});
const bodyRefContextDefaultValue = {
    current: null
};
const useBodyRefContext = ()=>{
    var _React_useContext;
    return (_React_useContext = _react.useContext(bodyRefContext)) != null ? _React_useContext : bodyRefContextDefaultValue;
};
const BodyRefContextProvider = bodyRefContext.Provider;

//# sourceMappingURL=bodyRefContext.js.map