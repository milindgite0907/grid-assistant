"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get TableRowIndexContextProvider () {
        return TableRowIndexContextProvider;
    },
    get tableRowIndexContextDefaultValue () {
        return tableRowIndexContextDefaultValue;
    },
    get useTableRowIndexContext () {
        return useTableRowIndexContext;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const rowIndexContext = _react.createContext(undefined);
const tableRowIndexContextDefaultValue = undefined;
const useTableRowIndexContext = ()=>{
    var _React_useContext;
    return (_React_useContext = _react.useContext(rowIndexContext)) != null ? _React_useContext : tableRowIndexContextDefaultValue;
};
const TableRowIndexContextProvider = rowIndexContext.Provider;

//# sourceMappingURL=rowIndexContext.js.map