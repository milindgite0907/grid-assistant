"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get HeaderRefContextProvider () {
        return HeaderRefContextProvider;
    },
    get headerRefContextDefaultValue () {
        return headerRefContextDefaultValue;
    },
    get useHeaderRefContext () {
        return useHeaderRefContext;
    }
});
const _interop_require_wildcard = require("@swc/helpers/_/_interop_require_wildcard");
const _react = /*#__PURE__*/ _interop_require_wildcard._(require("react"));
const headerRefContext = _react.createContext({
    current: null
});
const headerRefContextDefaultValue = {
    current: null
};
const useHeaderRefContext = ()=>{
    var _React_useContext;
    return (_React_useContext = _react.useContext(headerRefContext)) != null ? _React_useContext : headerRefContextDefaultValue;
};
const HeaderRefContextProvider = headerRefContext.Provider;

//# sourceMappingURL=headerRefContext.js.map