"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: Object.getOwnPropertyDescriptor(all, name).get
    });
}
_export(exports, {
    get DataGrid () {
        return _DataGrid.DataGrid;
    },
    get DataGridBody () {
        return _DataGridBody.DataGridBody;
    },
    get DataGridCell () {
        return _reactcomponents.DataGridCell;
    },
    get DataGridHeader () {
        return _DataGridHeader.DataGridHeader;
    },
    get DataGridHeaderCell () {
        return _reactcomponents.DataGridHeaderCell;
    },
    get DataGridRow () {
        return _DataGridRow.DataGridRow;
    },
    get DataGridSelectionCell () {
        return _reactcomponents.DataGridSelectionCell;
    },
    get renderDataGridBody_unstable () {
        return _DataGridBody.renderDataGridBody_unstable;
    },
    get renderDataGrid_unstable () {
        return _DataGrid.renderDataGrid_unstable;
    },
    get useDataGridBodyStyles_unstable () {
        return _DataGridBody.useDataGridBodyStyles_unstable;
    },
    get useDataGridBody_unstable () {
        return _DataGridBody.useDataGridBody_unstable;
    },
    get useDataGridHeaderStyles_unstable () {
        return _DataGridHeader.useDataGridHeaderStyles_unstable;
    },
    get useDataGridHeader_unstable () {
        return _DataGridHeader.useDataGridHeader_unstable;
    },
    get useDataGridRowStyles_unstable () {
        return _DataGridRow.useDataGridRowStyles_unstable;
    },
    get useDataGridRow_unstable () {
        return _DataGridRow.useDataGridRow_unstable;
    },
    get useDataGrid_unstable () {
        return _DataGrid.useDataGrid_unstable;
    }
});
const _DataGridBody = require("./components/DataGridBody");
const _DataGrid = require("./components/DataGrid");
const _DataGridRow = require("./components/DataGridRow");
const _DataGridHeader = require("./components/DataGridHeader");
const _reactcomponents = require("@fluentui/react-components");

//# sourceMappingURL=index.js.map